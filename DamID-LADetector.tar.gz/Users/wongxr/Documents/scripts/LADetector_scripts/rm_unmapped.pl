#removes large repetitive unmapped regions from LAD calls

use strict;
use warnings;

open (INTERSECT, "$ARGV[0]") or die;
open (LADS, "$ARGV[1]") or die;   #old LAD calls.
open (OUT, ">$ARGV[2]") or die;   #new LAD calls.


my %old;


#this stores all the LADs that have intersected with unmapped regions into a hash element
while (my $i = <INTERSECT>){
	chomp $i;
	my @array = split('\s+', $i);
	my $lads = join("\t", $array[0], $array[1], $array[2]);
	my $repeats = join("\t", $array[4], $array[5], $array[6]);
	$old{$lads} = $repeats;			#LAD coordinates get stored in keys and repeat coordinates in values
}


#this LOOKs for LADs that have intersected with unmapped regions and removes the unmapped chunk from the LAD
while (my $j = <LADS>){
	chomp $j;
	my @array = split('\s+', $j);
	my $lads = join("\t", $array[0], $array[1], $array[2]);
	
	
	#if a lad coordinate happens to have intersected with a repeat element,
	if ($old{$lads}){
		my @temp = split ('\s+', $old{$lads});
		my $rep_chr = $temp[0];
		my $rep_start = $temp[1];
		my $rep_stop = $temp[2];
		
		#if the repeat is embedded within a lad call 
		if ($rep_start>$array[1] && $rep_stop<$array[2]){
			print OUT "$array[0]\t$array[1]\t$rep_start\t1\n";
			print OUT "$array[0]\t$rep_stop\t$array[2]\t1\n";
		}
		#else if repeat overlaps the entirety of LADs (remove that entire LAD)
		elsif ($rep_start<$array[1] && $rep_stop>$array[2]){
		}
		#if repeat overlaps entire half portion of LAD
		elsif ($rep_stop>$array[1]){
			print OUT "$array[0]\t$rep_stop\t$array[2]\t1\n";
		}
		#lastly if repeat overlaps entire half portion of LAD
		else {
			print OUT "$array[0]\t$array[1]\t$rep_start\t1\n";
		}
	}
	else {
		print OUT "$j\n";
	}
}
		
	
	

