#!/usr/bin/perl
#removes bins with same consecutive scores

open (FH, "$ARGV[0]") or die;      #this is your normalized bed input
open (OUT, ">$ARGV[1]") or die;    #processed output
open (REPEATS, ">$ARGV[2]") or die; #repeat rich regions


my $i = <FH>;
chomp $i;

my @temp = split('\s+', $i);

my $lastChr=$temp[0];
my $lastPosStop = $temp[2];
my $lastPosStart = $temp[1];
my $lastScore = $temp[3];



my $flag = 1;

my @repeats = ($i);


while (my $i = <FH>){
	chomp $i;
	my @array = split('\s+', $i);
	
	
	if ($array[0] ne $lastChr){
		$lastChr = $array[0];
	}
	
	
	my $result = sameScore($lastScore, $array[3]);
	
	if ($result == 1){
		push(@repeats, $i);
	}
	
	else {
		$lastScore = $array[3];
		#check number of elements in @repeats
		if (scalar @repeats < 3){						#the value of 3 here can be changed for optimization;
													
		
			foreach my $j (@repeats){
			print OUT "$j\n";
			}
		
			@repeats = ($i);
		}
		
		else {
			#foreach my $j (@repeats){
			#my @temp = split('\s+', $j);
			#print OUT "$temp[0]\t$temp[1]\t$temp[2]\t0\n";
			#}
		
			my @holder = split('\s+', $repeats[0]);
			my $repeat_min = $holder[1];
			
			@holder = split('\s+', $repeats[-1]);
			my $repeat_max = $holder[2];
			
			if (($repeat_max-$repeat_min) >30000){	
				print REPEATS "$holder[0]\t$repeat_min\t$repeat_max\t1\n";	
			}	
			else {
				print OUT "$holder[0]\t$repeat_min\t$repeat_max\t$holder[3]\n";
			}
			@repeats = ($i);
		
		}
	}
}

close(FH);
close(OUT);
close(REPEATS);
			
sub sameScore {

	my ($prevScore, $currScore) = @_;
	
	if ($prevScore - $currScore == 0){
		return 1;
	}
	
	else {
		return 0;
	}
		
}
